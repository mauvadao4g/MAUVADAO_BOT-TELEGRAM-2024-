import telebot
from decouple import config

token = config('TOKEN_BOT')

bot = telebot.TeleBot(token)

bot.send_message(823289912, 'Opa, tudo certo ?')
